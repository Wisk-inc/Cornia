# Start here

Your ChatGPT-style coding agent. It plans, writes files, runs them in a
sandbox terminal, searches the web and generates images — using your own
ChatGPT account, no API key.

The app is `apps/agent`. The rest of the repo is the OAuth library it is
built on, which is why the whole project is here: the app imports those
packages and will not install without them.

---

## Run it (3 commands)

You need **Node 20+** and **[Bun](https://bun.sh)** (`curl -fsSL https://bun.sh/install | bash`).

```bash
bun install                     # ~460 packages, about 10s
bun run build                   # builds the library packages the app imports
bun run --cwd apps/agent dev    # starts the app
```

Open **http://localhost:3001** and click *Sign in with ChatGPT*.

That's it. On localhost the sign-in works with nothing else installed.

### No Bun? Use npm

```bash
npm install
npm run build
npm run dev --prefix apps/agent
```

### For production instead of dev

```bash
bun run build
bun run --cwd apps/agent build
bun run --cwd apps/agent start
```

---

## Running it on Replit

Import the project and press **Run**. A `.replit` file is included, so Run
installs, builds and starts *this* app on the port Replit assigns — you do
not need to type anything.

Two things still differ from localhost:

1. **Sign-in needs a browser extension.** ChatGPT's OAuth handoff only
   completes on its own from localhost. From a hosted URL the app shows a
   *One more step* screen linking to the
   [Sign in with ChatGPT extension](https://chromewebstore.google.com/detail/sign-in-with-chatgpt/odbgboachaefbbbdiffcefhpkekhfcna)
   (also on Firefox Add-ons). Install it, come back, press **Continue**.
   This is a requirement of the OAuth library, not something the app can
   work around.

2. **Open it in a real browser tab.** Replit's embedded webview blocks the
   sign-in popup. Use the "open in new tab" arrow on the webview.

If sign-in seems to hang, the app now says why after a few seconds —
usually a blocked popup. Allow popups for the site and retry.

---

## If chatting returns an error

That was a real bug and it is fixed in this build: the app was sending
reasoning parameters that the models reject. If you still see an error, it
now shows the actual reason from the API rather than "an error occurred" —
send me that text and I can fix it directly.

## What it can do in its sandbox

Each chat gets its own directory on the server, and the agent works in it
for real:

- **Clone a repo and run it.** "Clone github.com/psf/requests and run its
  tests" works — the sandbox has internet, so `git clone`, `npm install`
  and `pip install` all go through.
- **Fix its own mistakes.** A command that exits non-zero comes back
  flagged as work to do; the agent reads the error, changes the code and
  runs it again instead of reporting the failure to you.
- **Write and execute files** in any language the host has installed.
- **Download everything** it made: single files, or the whole workspace as
  a zip, from the folder icon.

Installs and clones can take a minute; the agent asks for a longer timeout
when it needs one (up to 15 minutes).

## First things to try

- "Write a CLI todo app in Python with tests, then run them."
- "Clone https://github.com/tiangolo/fastapi and show me how its routing works."
- "Benchmark two sorting approaches on 100k integers and show a table."
- Drop a file into the composer and ask about it.
- Open the folder icon (top right) to see and download everything it made.

The model picker is live — it lists whatever your account can reach,
including entries the public list hides. Settings & role lets you swap the
role or write your own system prompt.

---

## Settings you may want

All optional, set as environment variables:

| Variable | Effect |
| --- | --- |
| `AGENT_WORKSPACE_ROOT` | Where the sandbox directories live. Default `.agent-workspace`. |
| `AGENT_SANDBOX_COMMAND` | Launcher for the terminal, default `bash -lc`. Point it at a jail for real isolation, e.g. `firejail --quiet bash -lc`. |
| `BRAVE_SEARCH_API_KEY` / `TAVILY_API_KEY` | Better web search than the keyless DuckDuckGo fallback. |
| `CODEX_BASE_URL` | Point the provider at another Codex-compatible upstream. |

Full details in `apps/agent/README.md`.

---

## The one caveat worth reading

The agent's **file tools** are locked to a per-conversation sandbox
directory — paths that escape it, including via symlinks, are rejected.

Its **terminal is a real shell process** on whatever machine runs the
server. It has a timeout, a stripped environment and a blocklist for
obviously destructive commands, but a command can still read paths outside
the workspace. Run it on your own machine or in a container, and use
`AGENT_SANDBOX_COMMAND` if you want a hard boundary.

---

## What was verified before packaging

Driven in a real browser end to end, 37 automated checks: sign-in gate and
the hosted-extension screen, model picker with hidden models, planning,
file writes, sandbox command execution with live output, streamed markdown
and code, downloads, roles and custom prompts, theme, history across
reloads, and phone layouts at 320/390px. `bun install` and `bun run build`
were re-run against this exact extracted tree.

**Not verified, because it needs your account:** the real OAuth handshake,
the live model list, and image generation. Those are the parts only you can
exercise — if any of them misbehave, send me the error.
